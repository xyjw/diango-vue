from django.urls import path
from .views import *

urlpatterns = [
    # 视图类
    path('', userSet.as_view({
        'post': 'login_user',
        'get': 'check_user'
    }), name='userSet')
]

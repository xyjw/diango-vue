from django.apps import AppConfig

class CommodityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'commodity'
    verbose_name = '商品管理'

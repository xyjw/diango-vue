from .apps import CommodityConfig

default_app_config = 'commodity.CommodityConfig'
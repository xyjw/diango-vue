from django.urls import path
from .views import *

urlpatterns = [
    # 视图类
    path('', vocationSet.as_view({
        'get': 'get_all_data',
    }), name='all_data'),

    path('details/', vocationSet.as_view({
        'get': 'get_one_data',
        'post': 'create_data',
        'put': 'update_data'
    }), name='one_data'),
]

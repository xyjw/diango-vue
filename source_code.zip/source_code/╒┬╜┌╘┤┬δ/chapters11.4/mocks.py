from flask import jsonify, Flask

app = Flask(__name__)
# 增加配置，支持中文显示
app.config['JSON_AS_ASCII'] = False

res = {
    "state": "success",
    "msg": "获取成功",
    "data": {
        "commodityInfos": [
            [
                {
                    "id": 17,
                    "name": "80片纯水湿纸巾婴儿",
                    "sezes": "湿纸巾",
                    "types": "婴儿湿巾",
                    "price": 49.9,
                    "discount": 29.9,
                    "stock": 1235,
                    "sold": 5674,
                    "likes": 2318,
                    "created": "2020-02-24",
                    "img": "/media/imgs/p17.jpg",
                    "details": "/media/details/p17_details.jpg"
                },
                {
                    "id": 4,
                    "name": "婴儿防寒针织帽",
                    "sezes": "蓝色",
                    "types": "配饰",
                    "price": 50,
                    "discount": 39,
                    "stock": 2347,
                    "sold": 4521,
                    "likes": 903,
                    "created": "2020-02-24",
                    "img": "/media/imgs/p4.jpg",
                    "details": "/media/details/p4_details.jpg"
                },
                {
                    "id": 10,
                    "name": "超薄干爽绿帮纸尿裤",
                    "sezes": "大码",
                    "types": "纸尿裤",
                    "price": 209,
                    "discount": 159,
                    "stock": 1234,
                    "sold": 4321,
                    "likes": 3335,
                    "created": "2020-02-24",
                    "img": "/media/imgs/p10.jpg",
                    "details": "/media/details/p10_details.jpg"
                },
                {
                    "id": 16,
                    "name": "儿童安全座椅增高垫",
                    "sezes": "粉色",
                    "types": "安全座椅",
                    "price": 688,
                    "discount": 588,
                    "stock": 3421,
                    "sold": 3644,
                    "likes": 6245,
                    "created": "2020-02-24",
                    "img": "/media/imgs/p16.jpg",
                    "details": "/media/details/p16_details.jpg"
                }
            ],
            [
                {
                    "id": 13,
                    "name": "宝宝芝麻粉辅食调味拌饭",
                    "sezes": "辅食调味",
                    "types": "宝宝辅食",
                    "price": 59,
                    "discount": 39,
                    "stock": 1234,
                    "sold": 3453,
                    "likes": 2321,
                    "created": "2020-02-24",
                    "img": "/media/imgs/p13.jpg",
                    "details": "/media/details/p13_details.jpg"
                },
                {
                    "id": 5,
                    "name": "婴儿秋冬连体衣冬装衣服",
                    "sezes": "粉色",
                    "types": "童装",
                    "price": 145,
                    "discount": 111,
                    "stock": 1341,
                    "sold": 3412,
                    "likes": 2356,
                    "created": "2020-02-24",
                    "img": "/media/imgs/p5.jpg",
                    "details": "/media/details/p5_details.jpg"
                },
                {
                    "id": 14,
                    "name": "纽曼思海藻油DHA软胶囊",
                    "sezes": "DHA软胶囊",
                    "types": "营养品",
                    "price": 499,
                    "discount": 399,
                    "stock": 3231,
                    "sold": 3412,
                    "likes": 1234,
                    "created": "2020-02-24",
                    "img": "/media/imgs/p14.jpg",
                    "details": "/media/details/p14_details.jpg"
                },
                {
                    "id": 7,
                    "name": "外出服抱衣加厚冬季",
                    "sezes": "粉色",
                    "types": "童装",
                    "price": 166,
                    "discount": 111,
                    "stock": 213,
                    "sold": 2341,
                    "likes": 1233,
                    "created": "2020-02-24",
                    "img": "/media/imgs/p7.jpg",
                    "details": "/media/details/p7_details.jpg"
                }
            ]
        ],
        "clothes": [
            {
                "id": 4,
                "name": "婴儿防寒针织帽",
                "sezes": "蓝色",
                "types": "配饰",
                "price": 50,
                "discount": 39,
                "stock": 2347,
                "sold": 4521,
                "likes": 903,
                "created": "2020-02-24",
                "img": "/media/imgs/p4.jpg",
                "details": "/media/details/p4_details.jpg"
            },
            {
                "id": 5,
                "name": "婴儿秋冬连体衣冬装衣服",
                "sezes": "粉色",
                "types": "童装",
                "price": 145,
                "discount": 111,
                "stock": 1341,
                "sold": 3412,
                "likes": 2356,
                "created": "2020-02-24",
                "img": "/media/imgs/p5.jpg",
                "details": "/media/details/p5_details.jpg"
            },
            {
                "id": 7,
                "name": "外出服抱衣加厚冬季",
                "sezes": "粉色",
                "types": "童装",
                "price": 166,
                "discount": 111,
                "stock": 213,
                "sold": 2341,
                "likes": 1233,
                "created": "2020-02-24",
                "img": "/media/imgs/p7.jpg",
                "details": "/media/details/p7_details.jpg"
            },
            {
                "id": 2,
                "name": "儿童长袖加厚防寒加绒衫",
                "sezes": "玫红",
                "types": "童装",
                "price": 121,
                "discount": 66,
                "stock": 1234,
                "sold": 2111,
                "likes": 599,
                "created": "2020-02-24",
                "img": "/media/imgs/p2.jpg",
                "details": "/media/details/p2_details.jpg"
            },
            {
                "id": 1,
                "name": "婴儿衣服加厚连体衣",
                "sezes": "粉色",
                "types": "童装",
                "price": 199,
                "discount": 188,
                "stock": 1314,
                "sold": 1666,
                "likes": 666,
                "created": "2020-02-24",
                "img": "/media/imgs/p1.jpg",
                "details": "/media/details/p1_details.jpg"
            }
        ],
        "food": [
            {
                "id": 13,
                "name": "宝宝芝麻粉辅食调味拌饭",
                "sezes": "辅食调味",
                "types": "宝宝辅食",
                "price": 59,
                "discount": 39,
                "stock": 1234,
                "sold": 3453,
                "likes": 2321,
                "created": "2020-02-24",
                "img": "/media/imgs/p13.jpg",
                "details": "/media/details/p13_details.jpg"
            },
            {
                "id": 14,
                "name": "纽曼思海藻油DHA软胶囊",
                "sezes": "DHA软胶囊",
                "types": "营养品",
                "price": 499,
                "discount": 399,
                "stock": 3231,
                "sold": 3412,
                "likes": 1234,
                "created": "2020-02-24",
                "img": "/media/imgs/p14.jpg",
                "details": "/media/details/p14_details.jpg"
            },
            {
                "id": 12,
                "name": "宝宝零食儿童营养磨牙饼干",
                "sezes": "饼干",
                "types": "宝宝辅食",
                "price": 66,
                "discount": 38,
                "stock": 1543,
                "sold": 1845,
                "likes": 3245,
                "created": "2020-02-24",
                "img": "/media/imgs/p12.jpg",
                "details": "/media/details/p12_details.jpg"
            },
            {
                "id": 9,
                "name": "澳洲进口Aptamil爱他美",
                "sezes": "1段",
                "types": "进口奶粉",
                "price": 399,
                "discount": 366,
                "stock": 1233,
                "sold": 1231,
                "likes": 666,
                "created": "2020-02-24",
                "img": "/media/imgs/p9.jpg",
                "details": "/media/details/p9_details.jpg"
            },
            {
                "id": 11,
                "name": "婴儿面条宝宝辅食无添加",
                "sezes": "面条",
                "types": "宝宝辅食",
                "price": 30,
                "discount": 20,
                "stock": 3211,
                "sold": 1231,
                "likes": 2152,
                "created": "2020-02-24",
                "img": "/media/imgs/p11.jpg",
                "details": "/media/details/p11_details.jpg"
            }
        ],
        "goods": [
            {
                "id": 17,
                "name": "80片纯水湿纸巾婴儿",
                "sezes": "湿纸巾",
                "types": "婴儿湿巾",
                "price": 49.9,
                "discount": 29.9,
                "stock": 1235,
                "sold": 5674,
                "likes": 2318,
                "created": "2020-02-24",
                "img": "/media/imgs/p17.jpg",
                "details": "/media/details/p17_details.jpg"
            },
            {
                "id": 10,
                "name": "超薄干爽绿帮纸尿裤",
                "sezes": "大码",
                "types": "纸尿裤",
                "price": 209,
                "discount": 159,
                "stock": 1234,
                "sold": 4321,
                "likes": 3335,
                "created": "2020-02-24",
                "img": "/media/imgs/p10.jpg",
                "details": "/media/details/p10_details.jpg"
            },
            {
                "id": 16,
                "name": "儿童安全座椅增高垫",
                "sezes": "粉色",
                "types": "安全座椅",
                "price": 688,
                "discount": 588,
                "stock": 3421,
                "sold": 3644,
                "likes": 6245,
                "created": "2020-02-24",
                "img": "/media/imgs/p16.jpg",
                "details": "/media/details/p16_details.jpg"
            },
            {
                "id": 3,
                "name": "婴儿实木摇摇床",
                "sezes": "原木色",
                "types": "婴儿床",
                "price": 1099,
                "discount": 999,
                "stock": 2346,
                "sold": 1322,
                "likes": 333,
                "created": "2020-02-24",
                "img": "/media/imgs/p3.jpg",
                "details": "/media/details/p3_details.jpg"
            },
            {
                "id": 15,
                "name": "婴儿推车可坐可躺",
                "sezes": "蓝色",
                "types": "婴儿车",
                "price": 888,
                "discount": 439,
                "stock": 1234,
                "sold": 1245,
                "likes": 2353,
                "created": "2020-02-24",
                "img": "/media/imgs/p15.jpg",
                "details": "/media/details/p15_details.jpg"
            }
        ]
    }
}

@app.route('/api/v1/home/', methods=['GET'])
def indexViews():
    return jsonify(res)


if __name__ == '__main__':
    app.run(
        host='0.0.0.0',
        port=8000,
        debug=True
    )

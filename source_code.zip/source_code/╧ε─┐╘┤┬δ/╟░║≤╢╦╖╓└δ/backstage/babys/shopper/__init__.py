from .apps import ShopperConfig

default_app_config = 'shopper.ShopperConfig'